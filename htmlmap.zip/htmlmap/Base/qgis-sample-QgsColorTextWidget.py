# coding: utf-8
from qgis.gui import QgsColorTextWidget

color_text_widget = QgsColorTextWidget()

color_text_widget.show()
