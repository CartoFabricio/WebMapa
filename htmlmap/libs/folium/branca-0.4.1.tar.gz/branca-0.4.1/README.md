[![PyPI Package](https://img.shields.io/pypi/v/branca.svg)](https://pypi.python.org/pypi/branca) [![Build Status](https://travis-ci.org/python-visualization/branca.svg?branch=master)](https://travis-ci.org/python-visualization/branca) [![Gitter](https://badges.gitter.im/python-visualization/folium.svg)](https://gitter.im/python-visualization/folium)

# Branca

This library is a spinoff from [folium](https://github.com/python-visualization/folium),
that would host the non-map-specific features.

It may become a HTML+JS generation library in the future.

It is based on Jinja2 only.

There's no documentation,
but you can [browse the examples](http://nbviewer.jupyter.org/github/python-visualization/branca/tree/master/examples) gallery.
